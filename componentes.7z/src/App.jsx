import { useState } from 'react'
import './App.css'
import Conversa from './Conversa'

function App() {
  return(
    <div className='pagina'>
    <Conversa/>
    </div>
  )
}

export default App
