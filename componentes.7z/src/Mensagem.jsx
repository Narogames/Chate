import './style_conversa.css'
export default function Mensagem(){
    return(
       <div className="balao">
        <img className='balao_img' src="https://static.vecteezy.com/system/resources/thumbnails/011/287/592/small_2x/colorful-text-box-speech-bubble-frame-talk-chat-box-speak-balloon-thinking-balloon-conversation-box-decoration-png.png"></img>
        <h3 className="texto_balao">Achei o produto muito ruim </h3>
        </div>
    )
}
