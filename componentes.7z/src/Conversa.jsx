import'./style_conversa.css'
import Mensagem from './Mensagem'
import Mensagem_Cliente from './Mensagem_Cliente'
import Input_Conversa from './Input_Conversa'
export default function Conversa(){
    return(
        <div>
        <header className="header">
            <button className='imagem'></button>
            <img src='https://cdn-icons-png.flaticon.com/512/17/17004.png' className='imagem_usuario'></img>
           <div className='div_nomeusuario'> <h1 className="nome">Burguer King</h1>
           <p className='descricao_usuario'>Batata Cheddar</p> </div>
        </header>
        <Mensagem/>
        <Mensagem_Cliente/>
        <Input_Conversa/>
        </div>
    )
}